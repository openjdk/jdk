/*
 * Copyright (c) 2023, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
package common.config;

import static common.config.ConfigurationTest.getPath;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.Iterator;
import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.stream.EventFilter;
import javax.xml.stream.Location;
import javax.xml.stream.StreamFilter;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLReporter;
import javax.xml.stream.XMLResolver;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.Comment;
import javax.xml.stream.events.DTD;
import javax.xml.stream.events.EndDocument;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.EntityDeclaration;
import javax.xml.stream.events.EntityReference;
import javax.xml.stream.events.Namespace;
import javax.xml.stream.events.ProcessingInstruction;
import javax.xml.stream.events.StartDocument;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.util.XMLEventAllocator;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * ** does not work: because of interfering configuration file for impls **
 */

/**
 * @test @bug 8303530
 * @library /javax/xml/jaxp/libs /javax/xml/jaxp/unittest
 * @modules java.xml/jdk.xml.internal
 * @run testng/othervm common.config.StAXImplTest
 * @summary verifies that JAXP configuration file is customizable with a system
 * property "java.xml.config.file".
 */
public class StAXImplTest {

    enum Factory {
        EVENT, INPUT, OUTPUT
    }
    
    @Test(dataProvider = "getImpl")
    public void testEventFactory(Factory factory, String config, String expected) throws Exception {
        if (config != null) {
            System.out.println(getPath(config));
            System.setProperty(ConfigurationTest.SP_CONFIG, getPath(config));
        }

        switch (factory) {
            case EVENT:
                XMLEventFactory ef = XMLEventFactory.newFactory();
                System.out.println(ef.getClass().getName());
                Assert.assertEquals(ef.getClass().getName(), expected);
                break;
            case INPUT:
                XMLInputFactory xif = XMLInputFactory.newFactory();
                System.out.println(xif.getClass().getName());
                Assert.assertEquals(xif.getClass().getName(), expected);
                break;  
            case OUTPUT:
                XMLOutputFactory xof = XMLOutputFactory.newFactory();
                System.out.println(xof.getClass().getName());
                Assert.assertEquals(xof.getClass().getName(), expected);
                break; 
        }

        System.clearProperty(ConfigurationTest.SP_CONFIG);
    }

    @DataProvider(name = "getImpl")
    public Object[][] getImpl() {

        return new Object[][]{
            {Factory.EVENT, null, "com.sun.xml.internal.stream.events.XMLEventFactoryImpl"},
            {Factory.EVENT, "jaxpImpls.properties", "common.config.StAXImplTest$EventFactoryImpl"},
            {Factory.INPUT, null, "com.sun.xml.internal.stream.XMLInputFactoryImpl"},
            {Factory.INPUT, "jaxpImpls.properties", "common.config.StAXImplTest$InputFactoryImpl"},
            {Factory.OUTPUT, null, "com.sun.xml.internal.stream.XMLOutputFactoryImpl"},
            {Factory.OUTPUT, "jaxpImpls.properties", "common.config.StAXImplTest$OutputFactoryImpl"},
        };
    }


    public static class EventFactoryImpl extends XMLEventFactory {

        @Override
        public void setLocation(Location location) {
            // do nothing
        }

        @Override
        public Attribute createAttribute(String prefix, String namespaceURI, String localName, String value) {
            return null;
        }

        @Override
        public Attribute createAttribute(String localName, String value) {
            return null;
        }

        @Override
        public Attribute createAttribute(QName name, String value) {
            return null;
        }

        @Override
        public Namespace createNamespace(String namespaceURI) {
            return null;
        }

        @Override
        public Namespace createNamespace(String prefix, String namespaceUri) {
            return null;
        }

        @Override
        public StartElement createStartElement(QName name, Iterator<? extends Attribute> attributes, Iterator<? extends Namespace> namespaces) {
            return null;
        }

        @Override
        public StartElement createStartElement(String prefix, String namespaceUri, String localName) {
            return null;
        }

        @Override
        public StartElement createStartElement(String prefix, String namespaceUri, String localName, Iterator<? extends Attribute> attributes, Iterator<? extends Namespace> namespaces) {
            return null;
        }

        @Override
        public StartElement createStartElement(String prefix, String namespaceUri, String localName, Iterator<? extends Attribute> attributes, Iterator<? extends Namespace> namespaces, NamespaceContext context) {
            return null;
        }

        @Override
        public EndElement createEndElement(QName name, Iterator<? extends Namespace> namespaces) {
            return null;
        }

        @Override
        public EndElement createEndElement(String prefix, String namespaceUri, String localName) {
            return null;
        }

        @Override
        public EndElement createEndElement(String prefix, String namespaceUri, String localName, Iterator<? extends Namespace> namespaces) {
            return null;
        }

        @Override
        public Characters createCharacters(String content) {
            return null;
        }

        @Override
        public Characters createCData(String content) {
            return null;
        }

        @Override
        public Characters createSpace(String content) {
            return null;
        }

        @Override
        public Characters createIgnorableSpace(String content) {
            return null;
        }

        @Override
        public StartDocument createStartDocument() {
            return null;
        }

        @Override
        public StartDocument createStartDocument(String encoding, String version, boolean standalone) {
            return null;
        }

        @Override
        public StartDocument createStartDocument(String encoding, String version) {
            return null;
        }

        @Override
        public StartDocument createStartDocument(String encoding) {
            return null;
        }

        @Override
        public EndDocument createEndDocument() {
            return null;
        }

        @Override
        public EntityReference createEntityReference(String name, EntityDeclaration declaration) {
            return null;
        }

        @Override
        public Comment createComment(String text) {
            return null;
        }

        @Override
        public ProcessingInstruction createProcessingInstruction(String target, String data) {
            return null;
        }

        @Override
        public DTD createDTD(String dtd) {
            return null;
        }
        
    }
    
    public static class InputFactoryImpl extends XMLInputFactory {

        @Override
        public XMLStreamReader createXMLStreamReader(Reader reader) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamReader createXMLStreamReader(Source source) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamReader createXMLStreamReader(InputStream stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamReader createXMLStreamReader(InputStream stream, String encoding) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamReader createXMLStreamReader(String systemId, InputStream stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamReader createXMLStreamReader(String systemId, Reader reader) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(Reader reader) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(String systemId, Reader reader) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(XMLStreamReader reader) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(Source source) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(InputStream stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(InputStream stream, String encoding) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createXMLEventReader(String systemId, InputStream stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamReader createFilteredReader(XMLStreamReader reader, StreamFilter filter) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventReader createFilteredReader(XMLEventReader reader, EventFilter filter) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLResolver getXMLResolver() {
            return null;
        }

        @Override
        public void setXMLResolver(XMLResolver resolver) {
            // do nothing
        }

        @Override
        public XMLReporter getXMLReporter() {
            return null;
        }

        @Override
        public void setXMLReporter(XMLReporter reporter) {
            // do nothing
        }

        @Override
        public void setProperty(String name, Object value) throws IllegalArgumentException {
            // do nothing
        }

        @Override
        public Object getProperty(String name) throws IllegalArgumentException {
            return null;
        }

        @Override
        public boolean isPropertySupported(String name) {
            return false;
        }

        @Override
        public void setEventAllocator(XMLEventAllocator allocator) {
            // do nothing
        }

        @Override
        public XMLEventAllocator getEventAllocator() {
            return null;
        }
        
    }
    
    public static class OutputFactoryImpl extends XMLOutputFactory {

        @Override
        public XMLStreamWriter createXMLStreamWriter(Writer stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamWriter createXMLStreamWriter(OutputStream stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamWriter createXMLStreamWriter(OutputStream stream, String encoding) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLStreamWriter createXMLStreamWriter(Result result) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventWriter createXMLEventWriter(Result result) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventWriter createXMLEventWriter(OutputStream stream) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventWriter createXMLEventWriter(OutputStream stream, String encoding) throws XMLStreamException {
            return null;
        }

        @Override
        public XMLEventWriter createXMLEventWriter(Writer stream) throws XMLStreamException {
            return null;
        }

        @Override
        public void setProperty(String name, Object value) throws IllegalArgumentException {
            // do nothing
        }

        @Override
        public Object getProperty(String name) throws IllegalArgumentException {
            return null;
        }

        @Override
        public boolean isPropertySupported(String name) {
            return false;
        }
        
    }
}
